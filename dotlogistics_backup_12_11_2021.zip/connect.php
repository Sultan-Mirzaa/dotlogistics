<?php

$con = mysqli_connect('localhost','dotlogistics','dotlogistics@123!@#','dotlogistics');

?>